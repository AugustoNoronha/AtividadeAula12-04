
// 01)
var nickName:String = "Augustinho";
print(nickName);
var name = "Augusto";


//02)

var nameComprador = "";
var cpfComprador = "";
let valorCarro = 31000;
let modeloCarro = "ford fiesta";

//03)
// As anotações de tipo no swith são usadas para declara qaul o tipo da variavel.
// como por exemplo var nickname:String = "Augustinho" neste caso a var nickName está 
// sendo identificada como String. caso els estiivece sendo declara como var nickName = "Augustinho" futuramente eu poderia atribuir um outro valor como numerioc ou buleano nas variavel de nome nickName

//04)
var intValue = 1
var doubleValue = 1.3
var valueString = String(intValue)
var valueString = String(doubleValue)

//05)

//type safe: 
// Swift é uma linguagem de tipo seguro. Uma linguagem de tipo seguro incentiva você a ser claro sobre os tipos de valores com os quais seu código pode trabalhar. Se parte do seu código espera uma String, você não pode passar um Int por engano.

//type inference

// Se você não especificar o tipo de valor de que precisa, o Swift usa a inferência de tipo para descobrir o tipo apropriado. A inferência de tipo permite que um compilador deduza o tipo de uma expressão específica automaticamente ao compilar seu código, simplesmente examinando os valores fornecidos.