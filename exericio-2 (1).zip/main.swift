//1 
//serve para declara uma variavel ou constante que tem valor ou não, para passalos batsa usar uma ? no final

//2
var array = [1,2]
var set1: Set = [3.2,4.2,5.2]
var notEmpytSet = ["nome":"Augusto", "rua":"Vinicius de morais", "bairro":"luxmeburgo", "conjuge":"nenhum",]
print(array)
print(set1)
print(notEmpytSet)

//3
//array são ordenas e possuem indice, ja o set não te ordem não possuem indice e aceitam somente um item como mesmo valor

//4
var array2 =  [1, 13, 13, 26, 38, 38, 39, 41, 50, 50, 74, 74, 80, 90, 100]
var set2: Set = [1, 13, 13, 26, 38, 38, 39, 41, 50, 50, 74, 74, 80, 90, 100]
var arrayset = Array(set2)

print(arrayset)

//5

// var soma:Int?
// for (var i = 0; i < 10; i++){
//   soma += arrayset[i]
// }